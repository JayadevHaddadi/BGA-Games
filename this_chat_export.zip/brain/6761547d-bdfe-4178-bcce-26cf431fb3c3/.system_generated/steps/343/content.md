Title: Live Content

Description: Fetched live

Source: https://en.doc.boardgamearena.com/BGA_Game_licenses

---

<!DOCTYPE html>
<html class="client-nojs" lang="en" dir="ltr">
<head>
<meta charset="UTF-8"/>
<title>BGA Game licenses - Board Game Arena</title>
<script>document.documentElement.className="client-js";RLCONF={"wgBreakFrames":false,"wgSeparatorTransformTable":["",""],"wgDigitTransformTable":["",""],"wgDefaultDateFormat":"dmy","wgMonthNames":["","January","February","March","April","May","June","July","August","September","October","November","December"],"wgRequestId":"ab07caac5528e10f14b9a893","wgCSPNonce":false,"wgCanonicalNamespace":"","wgCanonicalSpecialPageName":false,"wgNamespaceNumber":0,"wgPageName":"BGA_Game_licenses","wgTitle":"BGA Game licenses","wgCurRevisionId":30780,"wgRevisionId":30780,"wgArticleId":131,"wgIsArticle":true,"wgIsRedirect":false,"wgAction":"view","wgUserName":null,"wgUserGroups":["*"],"wgCategories":["Studio"],"wgPageContentLanguage":"en","wgPageContentModel":"wikitext","wgRelevantPageName":"BGA_Game_licenses","wgRelevantArticleId":131,"wgIsProbablyEditable":false,"wgRelevantPageIsProbablyEditable":false,"wgRestrictionEdit":[],"wgRestrictionMove":[],"wgVisualEditor":{"pageLanguageCode":"en","pageLanguageDir":
"ltr","pageVariantFallbacks":"en"},"wgVector2022PreviewPages":[],"wgEditSubmitButtonLabelPublish":false};RLSTATE={"site.styles":"ready","user.styles":"ready","user":"ready","user.options":"loading","skins.vector.styles.legacy":"ready","ext.visualEditor.desktopArticleTarget.noscript":"ready"};RLPAGEMODULES=["site","mediawiki.page.ready","mediawiki.toc","skins.vector.legacy.js","ext.visualEditor.desktopArticleTarget.init","ext.visualEditor.targetLoader"];</script>
<script>(RLQ=window.RLQ||[]).push(function(){mw.loader.implement("user.options@12s5i",function($,jQuery,require,module){mw.user.tokens.set({"patrolToken":"+\\","watchToken":"+\\","csrfToken":"+\\"});});});</script>
<link rel="stylesheet" href="/load.php?lang=en&amp;modules=ext.visualEditor.desktopArticleTarget.noscript%7Cskins.vector.styles.legacy&amp;only=styles&amp;skin=vector"/>
<script async="" src="/load.php?lang=en&amp;modules=startup&amp;only=scripts&amp;raw=1&amp;skin=vector"></script>
<meta name="generator" content="MediaWiki 1.39.0"/>
<meta name="format-detection" content="telephone=no"/>
<meta name="viewport" content="width=1000"/>
<link rel="canonical" href="http://en.boardgamearena.com/doc/BGA_Game_licenses"/>
<link rel="icon" href="//en.boardgamearena.com/favicon.ico"/>
<link rel="search" type="application/opensearchdescription+xml" href="/opensearch_desc.php" title="Board Game Arena (en)"/>
<link rel="EditURI" type="application/rsd+xml" href="//en.doc.boardgamearena.com/api.php?action=rsd"/>
</head>
<body class="mediawiki ltr sitedir-ltr mw-hide-empty-elt ns-0 ns-subject page-BGA_Game_licenses rootpage-BGA_Game_licenses skin-vector action-view skin-vector-legacy vector-feature-language-in-header-enabled vector-feature-language-in-main-page-header-disabled vector-feature-language-alert-in-sidebar-disabled vector-feature-sticky-header-disabled vector-feature-sticky-header-edit-disabled vector-feature-table-of-contents-disabled vector-feature-visual-enhancement-next-disabled"><div id="mw-page-base" class="noprint"></div>
<div id="mw-head-base" class="noprint"></div>
<div id="content" class="mw-body" role="main">
	<a id="top"></a>
	<div id="siteNotice"><div id="localNotice"><div class="sitenotice" lang="en" dir="ltr"><div style="font-size: 110%; background-color: ivory; padding: 0.5ex; border: 1px solid black; text-align: center;">
<p>This is a documentation for <a rel="nofollow" class="external text" href="http://boardgamearena.com">Board Game Arena</a>: play board games online&#160;!
</p>
</div></div></div></div>
	<div class="mw-indicators">
	</div>
	<h1 id="firstHeading" class="firstHeading mw-first-heading"><span class="mw-page-title-main">BGA Game licenses</span></h1>
	<div id="bodyContent" class="vector-body">
		<div id="siteSub" class="noprint">From Board Game Arena</div>
		<div id="contentSub"></div>
		<div id="contentSub2"></div>
		
		<div id="jump-to-nav"></div>
		<a class="mw-jump-link" href="#mw-head">Jump to navigation</a>
		<a class="mw-jump-link" href="#searchInput">Jump to search</a>
		<div id="mw-content-text" class="mw-body-content mw-content-ltr" lang="en" dir="ltr"><div class="mw-parser-output"><div id="toc" class="toc" role="navigation" aria-labelledby="mw-toc-heading"><input type="checkbox" role="button" id="toctogglecheckbox" class="toctogglecheckbox" style="display:none" /><div class="toctitle" lang="en" dir="ltr"><h2 id="mw-toc-heading">Contents</h2><span class="toctogglespan"><label class="toctogglelabel" for="toctogglecheckbox"></label></span></div>
<ul>
<li class="toclevel-1 tocsection-1"><a href="#What_is_a_&quot;license&quot;_exactly?"><span class="tocnumber">1</span> <span class="toctext">What is a "license" exactly?</span></a></li>
<li class="toclevel-1 tocsection-2"><a href="#Are_all_games_on_BGA_licensed_by_their_respective_copyright_owners?"><span class="tocnumber">2</span> <span class="toctext">Are all games on BGA licensed by their respective copyright owners?</span></a></li>
<li class="toclevel-1 tocsection-3"><a href="#Where_can_I_find_a_list_of_games_for_which_a_license_has_already_been_granted?"><span class="tocnumber">3</span> <span class="toctext">Where can I find a list of games for which a license has already been granted?</span></a></li>
<li class="toclevel-1 tocsection-4"><a href="#What_if_I_start_developing_a_game_that_is_not_on_the_&quot;Available_licences&quot;_list?"><span class="tocnumber">4</span> <span class="toctext">What if I start developing a game that is not on the "Available licences" list?</span></a></li>
<li class="toclevel-1 tocsection-5"><a href="#Wow,_I_WANT_to_develop_a_game_on_this_list!"><span class="tocnumber">5</span> <span class="toctext">Wow, I WANT to develop a game on this list!</span></a></li>
<li class="toclevel-1 tocsection-6"><a href="#What_needs_to_be_done_to_add_a_game_on_this_list?"><span class="tocnumber">6</span> <span class="toctext">What needs to be done to add a game on this list?</span></a></li>
<li class="toclevel-1 tocsection-7"><a href="#Why_aren&#39;t_all_the_best-selling_games_that_I_love_on_that_list?"><span class="tocnumber">7</span> <span class="toctext">Why aren't all the best-selling games that I love on that list?</span></a></li>
<li class="toclevel-1 tocsection-8"><a href="#I_want_to_make_my_prototype/unpublished_game_available_on_BGA"><span class="tocnumber">8</span> <span class="toctext">I want to make my prototype/unpublished game available on BGA</span></a></li>
<li class="toclevel-1 tocsection-9"><a href="#What_if_I_really_want_to_develop_a_particular_game_that_is_NOT_on_the_list_of_&quot;Available_licences&quot;?"><span class="tocnumber">9</span> <span class="toctext">What if I really want to develop a particular game that is NOT on the list of "Available licences"?</span></a>
<ul>
<li class="toclevel-2 tocsection-10"><a href="#0:_The_game_is_popular"><span class="tocnumber">9.1</span> <span class="toctext">0: The game is popular</span></a></li>
<li class="toclevel-2 tocsection-11"><a href="#1:_Determine_the_Publisher"><span class="tocnumber">9.2</span> <span class="toctext">1: Determine the Publisher</span></a></li>
<li class="toclevel-2 tocsection-12"><a href="#2:_Check_Publisher_Relation_with_BGA"><span class="tocnumber">9.3</span> <span class="toctext">2: Check Publisher Relation with BGA</span></a></li>
<li class="toclevel-2 tocsection-13"><a href="#3:_Check_Publisher&#39;s_Other_Available_Licenses"><span class="tocnumber">9.4</span> <span class="toctext">3: Check Publisher's Other Available Licenses</span></a></li>
<li class="toclevel-2 tocsection-14"><a href="#4:_Publisher_is_not_in_the_list"><span class="tocnumber">9.5</span> <span class="toctext">4: Publisher is not in the list</span></a></li>
</ul>
</li>
</ul>
</div>

<h2><span id="What_is_a_.22license.22_exactly.3F"></span><span class="mw-headline" id="What_is_a_&quot;license&quot;_exactly?">What is a "license" exactly?</span></h2>
<p>Almost all games on the Board Game Arena platform are adaptations of existing commercial "real" board games. In order to host an adaptation of one of these board games on a website, the copyright owners must first grant a license/authorisation to this website.
</p>
<h2><span id="Are_all_games_on_BGA_licensed_by_their_respective_copyright_owners.3F"></span><span class="mw-headline" id="Are_all_games_on_BGA_licensed_by_their_respective_copyright_owners?">Are all games on BGA licensed by their respective copyright owners?</span></h2>
<p>Yes, for all games that are not in the public domain, BGA has been granted an authorisation to create and host an online version.
</p>
<h2><span id="Where_can_I_find_a_list_of_games_for_which_a_license_has_already_been_granted.3F"></span><span class="mw-headline" id="Where_can_I_find_a_list_of_games_for_which_a_license_has_already_been_granted?">Where can I find a list of games for which a license has already been granted?</span></h2>
<p><a rel="nofollow" class="external text" href="https://studio.boardgamearena.com/#!licensing">Check the list of available licenses</a>
</p><p>(NB: this page is restricted to developers registered in BGA studio. You'll need to enter your BGA studio credentials to access it)
</p>
<h2><span id="What_if_I_start_developing_a_game_that_is_not_on_the_.22Available_licences.22_list.3F"></span><span class="mw-headline" id="What_if_I_start_developing_a_game_that_is_not_on_the_&quot;Available_licences&quot;_list?">What if I start developing a game that is not on the "Available licences" list?</span></h2>
<p>We allow developers to start any project in the Studio. But when you submit your project to go live on BGA, it will be rejected during the review process if BGA doesn't hold a proper license for the game.
</p><p>Exception: games in the public domain are of course not concerned.
</p>
<h2><span id="Wow.2C_I_WANT_to_develop_a_game_on_this_list.21"></span><span class="mw-headline" id="Wow,_I_WANT_to_develop_a_game_on_this_list!">Wow, I WANT to develop a game on this list!</span></h2>
<p>Great!&#160;:)
</p><p>But before creating a new project, please takes some seconds to check that someone is not already developing this game. If it is the case, maybe you can propose to join the project?
</p><p><a rel="nofollow" class="external text" href="http://studio.boardgamearena.com/projects">Check the list of current projects</a>
</p><p>Also, first thing to do when starting a project of that list is to request the game image files. Sometimes we already have them, sometimes we'll have to ask the publisher. Since it can be a while between the time the publisher grants the license and when a developer starts a project, this contact also allows to check that everything is still ok on the licensing side.
</p><p>Try establishing a contact with the publisher or designer before developing a new game. To release the implementation as a public game, the publisher must approve the game during alpha test phase. Without publisher support your game will remain private indefinitely.
</p>
<h2><span id="What_needs_to_be_done_to_add_a_game_on_this_list.3F"></span><span class="mw-headline" id="What_needs_to_be_done_to_add_a_game_on_this_list?">What needs to be done to add a game on this list?</span></h2>
<p>The copyright owners have to give an license/authorisation to BGA.
</p><p>Publishers do not have to pay anything to BGA for this, they just need to give their "go". Most of the time, publishers want to have a formal agreement and we sign a contract with them.
</p>
<h2><span id="Why_aren.27t_all_the_best-selling_games_that_I_love_on_that_list.3F"></span><span class="mw-headline" id="Why_aren't_all_the_best-selling_games_that_I_love_on_that_list?">Why aren't all the best-selling games that I love on that list?</span></h2>
<p>As you can imagine, the more popular a game is, the most difficult it can be to get an agreement to host this game on BGA.
</p><p>So if you are thinking about a very popular game that is not on this list, the reason is most likely "we asked but it was not possible" and not "we didn't think of it".
</p><p>We are really happy to have been able to build a very nice platform that managed to convince some of the most prestigious publishers to host their games here, but of course we can't convince -everyone-.
</p>
<h2><span id="I_want_to_make_my_prototype.2Funpublished_game_available_on_BGA"></span><span class="mw-headline" id="I_want_to_make_my_prototype/unpublished_game_available_on_BGA">I want to make my prototype/unpublished game available on BGA</span></h2>
<p>We will only make accessible published games that can be bought somewhere, or will be in a near future.
</p><p>Any other games like prototypes, self-published, print-n-play, ... can be coded on the Studio. But on the production side, it will not go further than private alpha, so it will only accessible to friends you invite to the private alpha, not to all BGA players (until it becomes published).
</p><p>The only exception is popular public domain games, that are by definition not published. If you want to add a public domain game to BGA, please first ask the Studio support so we can consider if the game is popular enough to have its place on BGA.
</p>
<h2><span id="What_if_I_really_want_to_develop_a_particular_game_that_is_NOT_on_the_list_of_.22Available_licences.22.3F"></span><span class="mw-headline" id="What_if_I_really_want_to_develop_a_particular_game_that_is_NOT_on_the_list_of_&quot;Available_licences&quot;?">What if I really want to develop a particular game that is NOT on the list of "Available licences"?</span></h2>
<p>This is the most frequently asked question, so for a detailed answer please follow the white rabbit down these numbered instructions:
</p>
<h3><span class="mw-headline" id="0:_The_game_is_popular">0: The game is popular</span></h3>
<p>If the game is already popular (lets say top 1000 on bgg) its likely BGA already contacted them and we don't have a license OR its secretly developed by BGA already, so before you proceed any further check with dev team on forum or discord to see if anybody has more information.
</p>
<h3><span class="mw-headline" id="1:_Determine_the_Publisher">1: Determine the Publisher</span></h3>
<p>First, you should determine who is the owner of the digital rights of the game. Most of the time, this is the original publisher of the game. The original publisher is not always easy to find, because very often board games are translated and published in different countries by a local publisher.
</p><p>To find the original publisher:
</p>
<ul><li>check in which country the game has been published first (ex: If it's in Poland, the original publisher is probably Polish).</li>
<li>check the copyright notice at the end of the rules, where the original publisher is mentioned almost every time.</li>
<li>very often, if two publishers are mentioned on a gamebox, the well-known publisher is the local publisher from your country and the other one is the original publisher.</li></ul>
<p>Special case: if the game is themed with a prestigious licence (Star Wars, Lord of the Rings, some TV show, some well known novel...), you can stop here immediately: contracts between game publishers and prestigious licenses owners are very restrictive, and there is 99% chance that an online adaptation on BGA would be impossible to manage.
</p><p>Continue to 2.
</p>
<h3><span class="mw-headline" id="2:_Check_Publisher_Relation_with_BGA">2: Check Publisher Relation with BGA</span></h3>
<p>Read the list of publishers from the <a rel="nofollow" class="external text" href="https://studio.boardgamearena.com/#!licensing">Available licenses</a> page to check if BGA is already working with this publisher.
</p><p>If YES, proceed to 3.
If NO, jump to 4.
</p><p>However, if the publisher is listed as "not working with BGA", you can stop here immediately. It happens that some publishers are not convinced or interested by online boardgaming and it is their right to think so. The BGA team regularly meets new publishers during board games events to show them the platform, so we're working on this but -again- we cannot convince everyone.
</p>
<h3><span id="3:_Check_Publisher.27s_Other_Available_Licenses"></span><span class="mw-headline" id="3:_Check_Publisher's_Other_Available_Licenses">3: Check Publisher's Other Available Licenses</span></h3>
<p>Is there already in the list a game licensed by this publisher that is available to be developed or under development?
</p><p>If YES: as a rule of thumb, we do not ask more than one game to a publisher at a time. When we ask a license for a game, the publisher naturally expects that this game will be developed and published online. So we develop and publish a game before asking for another.
If you really want to develop another game from this particular publisher, the best option for you is to help develop the game that is currently licensed and then ask us to request the game you'd like to develop.
</p><p>If NO: you can click on "template email" at the top of the licensing page to display a form that will help you generate an email to send to the publisher to request a new license.
</p><p>And if you are unsure, please check with us by filing a support request from the <a rel="nofollow" class="external text" href="https://studio.boardgamearena.com/support">studio support page</a> (it's always a good idea to ask if you are not sure&#160;;) )
</p>
<h3><span class="mw-headline" id="4:_Publisher_is_not_in_the_list">4: Publisher is not in the list</span></h3>
<p>We have never worked with this publisher before.
</p><p>If you have already developed a game on BGA, you can click on "template email" at the top of the <a rel="nofollow" class="external text" href="https://studio.boardgamearena.com/#!licensing">Available licenses page</a> to display a form that will help you generate an email to send to the publisher to request a new license.
</p><p>If this is your first game on BGA, we advise you to start with a game already on the list. Why? Because unfortunately, sometimes developers request a license, and then don't finish the development. When asking for a license, it's better if you have already shown your ability to realise an adaptation.
</p><p>Special case: if you know the publisher PERSONALLY, or have some contact there, please suggest them to check our page for game publishers <a rel="nofollow" class="external free" href="https://boardgamearena.com/#!gamepublishers">https://boardgamearena.com/#!gamepublishers</a> where they'll get information and find an email template to send to us if they are interested in granting BGA a license.
</p><p>Special case #2: if you are the publisher, represent the publisher, or the license owner (i.e. author of unpublished game) please check out <a rel="nofollow" class="external free" href="https://boardgamearena.com/#!gamepublishers">https://boardgamearena.com/#!gamepublishers</a> and if you are interested contact us by email! (you can use the email template available on this page).
</p>
<!-- 
NewPP limit report
Cached time: 20260925124830
Cache expiry: 86400
Reduced expiry: false
Complications: [show‐toc]
CPU time usage: 0.008 seconds
Real time usage: 0.009 seconds
Preprocessor visited node count: 42/1000000
Post‐expand include size: 0/2097152 bytes
Template argument size: 0/2097152 bytes
Highest expansion depth: 2/100
Expensive parser function count: 0/100
Unstrip recursion depth: 0/20
Unstrip post‐expand size: 0/5000000 bytes
-->
<!--
Transclusion expansion time report (%,ms,calls,template)
100.00%    0.000      1 -total
-->

<!-- Saved in parser cache with key tournoidoc139_en:pcache:idhash:131-0!canonical and timestamp 20260925124830 and revision id 30780.
 -->
</div>
<div class="printfooter" data-nosnippet="">Retrieved from "<a dir="ltr" href="http:///index.php?title=BGA_Game_licenses&amp;oldid=30780">http:///index.php?title=BGA_Game_licenses&amp;oldid=30780</a>"</div></div>
		<div id="catlinks" class="catlinks" data-mw="interface"><div id="mw-normal-catlinks" class="mw-normal-catlinks"><a href="/Special:Categories" title="Special:Categories">Category</a>: <ul><li><a href="/Category:Studio" title="Category:Studio">Studio</a></li></ul></div></div>
	</div>
</div>

<div id="mw-navigation">
	<h2>Navigation menu</h2>
	<div id="mw-head">
		

<nav id="p-personal" class="vector-menu mw-portlet mw-portlet-personal vector-user-menu-legacy" aria-labelledby="p-personal-label" role="navigation"  >
	<h3
		id="p-personal-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Personal tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="pt-login" class="mw-list-item"><a href="/index.php?title=Special:UserLogin&amp;returnto=BGA+Game+licenses" title="You are encouraged to log in; however, it is not mandatory [o]" accesskey="o"><span>Log in</span></a></li></ul>
		
	</div>
</nav>

		<div id="left-navigation">
			

<nav id="p-namespaces" class="vector-menu mw-portlet mw-portlet-namespaces vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-namespaces-label" role="navigation"  >
	<h3
		id="p-namespaces-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Namespaces</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-nstab-main" class="selected mw-list-item"><a href="/BGA_Game_licenses" title="View the content page [c]" accesskey="c"><span>Page</span></a></li><li id="ca-talk" class="new mw-list-item"><a href="/index.php?title=Talk:BGA_Game_licenses&amp;action=edit&amp;redlink=1" rel="discussion" title="Discussion about the content page (page does not exist) [t]" accesskey="t"><span>Discussion</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-variants" class="vector-menu mw-portlet mw-portlet-variants emptyPortlet vector-menu-dropdown" aria-labelledby="p-variants-label" role="navigation"  >
	<input type="checkbox"
		id="p-variants-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-variants"
		class="vector-menu-checkbox"
		aria-labelledby="p-variants-label"
	/>
	<label
		id="p-variants-label"
		 aria-label="Change language variant"
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">English</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

		</div>
		<div id="right-navigation">
			

<nav id="p-views" class="vector-menu mw-portlet mw-portlet-views vector-menu-tabs vector-menu-tabs-legacy" aria-labelledby="p-views-label" role="navigation"  >
	<h3
		id="p-views-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Views</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="ca-view" class="selected mw-list-item"><a href="/BGA_Game_licenses"><span>Read</span></a></li><li id="ca-viewsource" class="mw-list-item"><a href="/index.php?title=BGA_Game_licenses&amp;action=edit" title="This page is protected.&#10;You can view its source [e]" accesskey="e"><span>View source</span></a></li><li id="ca-history" class="mw-list-item"><a href="/index.php?title=BGA_Game_licenses&amp;action=history" title="Past revisions of this page [h]" accesskey="h"><span>View history</span></a></li></ul>
		
	</div>
</nav>

			

<nav id="p-cactions" class="vector-menu mw-portlet mw-portlet-cactions emptyPortlet vector-menu-dropdown" aria-labelledby="p-cactions-label" role="navigation"  title="More options" >
	<input type="checkbox"
		id="p-cactions-checkbox"
		role="button"
		aria-haspopup="true"
		data-event-name="ui.dropdown-p-cactions"
		class="vector-menu-checkbox"
		aria-labelledby="p-cactions-label"
	/>
	<label
		id="p-cactions-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">More</span>
	</label>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"></ul>
		
	</div>
</nav>

			
<div id="p-search" role="search" class="vector-search-box-vue  vector-search-box-show-thumbnail vector-search-box-auto-expand-width vector-search-box">
	<div>
			<h3 >
				<label for="searchInput">Search</label>
			</h3>
		<form action="/index.php" id="searchform"
			class="vector-search-box-form">
			<div id="simpleSearch"
				class="vector-search-box-inner"
				 data-search-loc="header-navigation">
				<input class="vector-search-box-input"
					 type="search" name="search" placeholder="Search Board Game Arena" aria-label="Search Board Game Arena" autocapitalize="sentences" title="Search Board Game Arena [f]" accesskey="f" id="searchInput"
				>
				<input type="hidden" name="title" value="Special:Search">
				<input id="mw-searchButton"
					 class="searchButton mw-fallbackSearchButton" type="submit" name="fulltext" title="Search the pages for this text" value="Search">
				<input id="searchButton"
					 class="searchButton" type="submit" name="go" title="Go to a page with this exact name if it exists" value="Go">
			</div>
		</form>
	</div>
</div>

		</div>
	</div>
	

<div id="mw-panel">
	<div id="p-logo" role="banner">
		<a class="mw-wiki-logo" href="/Main_Page"
			title="Visit the main page"></a>
	</div>
	

<nav id="p-navigation" class="vector-menu mw-portlet mw-portlet-navigation vector-menu-portal portal" aria-labelledby="p-navigation-label" role="navigation"  >
	<h3
		id="p-navigation-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Navigation</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="n-BoardGameArena.com" class="mw-list-item"><a href="http://boardgamearena.com" rel="nofollow"><span>BoardGameArena.com</span></a></li><li id="n-mainpage-description" class="mw-list-item"><a href="/Main_Page" title="Visit the main page [z]" accesskey="z"><span>Main page</span></a></li><li id="n-BGA-Studio-doc" class="mw-list-item"><a href="/Studio"><span>BGA Studio doc</span></a></li><li id="n-recentchanges" class="mw-list-item"><a href="/Special:RecentChanges" title="A list of recent changes in the wiki [r]" accesskey="r"><span>Recent changes</span></a></li></ul>
		
	</div>
</nav>

	

<nav id="p-tb" class="vector-menu mw-portlet mw-portlet-tb vector-menu-portal portal" aria-labelledby="p-tb-label" role="navigation"  >
	<h3
		id="p-tb-label"
		
		class="vector-menu-heading "
	>
		<span class="vector-menu-heading-label">Tools</span>
	</h3>
	<div class="vector-menu-content">
		
		<ul class="vector-menu-content-list"><li id="t-whatlinkshere" class="mw-list-item"><a href="/Special:WhatLinksHere/BGA_Game_licenses" title="A list of all wiki pages that link here [j]" accesskey="j"><span>What links here</span></a></li><li id="t-recentchangeslinked" class="mw-list-item"><a href="/Special:RecentChangesLinked/BGA_Game_licenses" rel="nofollow" title="Recent changes in pages linked from this page [k]" accesskey="k"><span>Related changes</span></a></li><li id="t-specialpages" class="mw-list-item"><a href="/Special:SpecialPages" title="A list of all special pages [q]" accesskey="q"><span>Special pages</span></a></li><li id="t-print" class="mw-list-item"><a href="javascript:print();" rel="alternate" title="Printable version of this page [p]" accesskey="p"><span>Printable version</span></a></li><li id="t-permalink" class="mw-list-item"><a href="/index.php?title=BGA_Game_licenses&amp;oldid=30780" title="Permanent link to this revision of this page"><span>Permanent link</span></a></li><li id="t-info" class="mw-list-item"><a href="/index.php?title=BGA_Game_licenses&amp;action=info" title="More information about this page"><span>Page information</span></a></li></ul>
		
	</div>
</nav>

	
</div>

</div>

<footer id="footer" class="mw-footer" role="contentinfo" >
	<ul id="footer-info">
	<li id="footer-info-lastmod"> This page was last edited on 22 July 2026, at 15:47.</li>
</ul>

	<ul id="footer-places">
	<li id="footer-places-privacy"><a href="/Board_Game_Arena:Privacy_policy">Privacy policy</a></li>
	<li id="footer-places-about"><a href="/Board_Game_Arena:About">About Board Game Arena</a></li>
	<li id="footer-places-disclaimer"><a href="/Board_Game_Arena:General_disclaimer">Disclaimers</a></li>
</ul>

	<ul id="footer-icons" class="noprint">
	<li id="footer-poweredbyico"><a href="https://www.mediawiki.org/"><img src="/resources/assets/poweredby_mediawiki_88x31.png" alt="Powered by MediaWiki" srcset="/resources/assets/poweredby_mediawiki_132x47.png 1.5x, /resources/assets/poweredby_mediawiki_176x62.png 2x" width="88" height="31" loading="lazy"/></a></li>
</ul>

</footer>

<script>(RLQ=window.RLQ||[]).push(function(){mw.config.set({"wgPageParseReport":{"limitreport":{"cputime":"0.008","walltime":"0.009","ppvisitednodes":{"value":42,"limit":1000000},"postexpandincludesize":{"value":0,"limit":2097152},"templateargumentsize":{"value":0,"limit":2097152},"expansiondepth":{"value":2,"limit":100},"expensivefunctioncount":{"value":0,"limit":100},"unstrip-depth":{"value":0,"limit":20},"unstrip-size":{"value":0,"limit":5000000},"timingprofile":["100.00%    0.000      1 -total"]},"cachereport":{"timestamp":"20260925124830","ttl":86400,"transientcontent":false}}});mw.config.set({"wgBackendResponseTime":333});});</script>
</body>
</html>

